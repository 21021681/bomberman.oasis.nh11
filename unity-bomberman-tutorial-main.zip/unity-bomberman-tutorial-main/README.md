# Bomberman (2D)

> Bomberman is a video game franchise originally released in Japan in July 1983. Bomberman gameplay involves strategically placing down bombs, which explode in multiple directions after a certain amount of time, in order to destroy obstacles and kill enemies and other players.

- **Difficulty**: Intermediate
- **Topics**: Tilemaps, Animation, Multiplayer
- **Version**: Unity 2020.3 (LTS)
- [**Download**](https://github.com/zigurous/unity-bomberman-tutorial/archive/refs/heads/main.zip)
- [**Watch Video**](https://youtu.be/8agb6x5RpOI)
